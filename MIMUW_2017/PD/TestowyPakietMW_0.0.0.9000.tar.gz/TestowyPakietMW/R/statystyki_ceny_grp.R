#'Poprawno�� Marki
#'
#'Sprawdza czy istnieje Marka o nazwie marka w zbiorze dane.
#'
#'@param marka Marka, dla kt�rej sprawdzamy czy istnieje w auta2012
#'@param dane Zbi�r danych, w kt�rych s� szukane marki
czy_marka_jest_poprawna <- function (marka, dane = auta2012) {
  return (marka %in% dane[, "Marka"])
}

#'Model w Marce
#'
#'Sprawdza czy dana Marka posiada Model w zbiorze dane.
#'
#'@param marka Marka, dla kt�rej sprawdzamy czy jest w niej Model model
#'@param model Model, dla kt�rego sprawdzamy czy jest w Marce marka.
#'@param dane Zbi�r danych, w kt�rym sprawdzane jest nasze zapytanie.
czy_marka_posiada_model <- function (marka, model, dane = auta2012) {
  samochody_naszej_marki <- filter(dane, Marka == marka)
  return (model %in% samochody_naszej_marki[, "Model"])
}

#'Poprawno�� Modelu
#'
#'Sprawdza czy dany model jest poprawnego formatu
#'
#'@param marka Marka danego modelu przekazywana dalej do funkcji czy_marka_posiada_model
#'@param model Model, kt�ry sprawdzdamy czy jest odpowiedniego formatu, czyli czy jest characterem.
#'@param dane Zbi�r danych, w kt�rym wszystko b�dzie sprawdzane.
czy_model_jest_poprawny <- function (marka, model, dane = auta2012) {
  if (is.character(model)) {
    return (czy_marka_posiada_model(marka, model, dane))
  } else {
    return (FALSE)
  }
}

#'Model w Roku
#'
#'Sprawdza czy dany model posiada auta o Roku Produkcji r�wynm rok.
#'
#'@param marka Marka szukanych samochod�w.
#'@param model Model szukanych samochod�w.
#'@param rok Rok, kt�ry spawdzamy czy istnieje w zbiorze dane.
#'@param dane Zbi�r danych, w kt�rym sprawdzane s� warunki.
czy_jest_dany_model_w_roku <- function (marka, model, rok, dane = auta2012) {
  samochody_naszej_marki_i_roku <- filter(dane, Marka == marka, Model == model)
  return (rok %in% samochody_naszej_marki_i_roku[, "Rok.produkcji"])
}

#'Poprawno�� Roku
#'
#'Sprawdza czy rok jest liczb�.
#'
#'@param marka Marka szukanych samochod�w.
#'@param model Model szukanych samochod�w.
#'@param rok Zmienna, kt�r� sprawdzamy czy jest odpowiedniego formatu.
#'@param dane Zbi�r danych, w kt�rym sprawdzane s� warunki.
czy_rok_jest_poprawny <- function (marka, model, rok, dane = auta2012) {
  if (is.numeric(rok)) {
    return (czy_jest_dany_model_w_roku(marka, model, rok, dane))
  } else {
    return (FALSE)
  }
}

#'Sprawdzenie parametr�w
#'
#'Sprawdza czy parametry wej�ciowe funkcji statystyki_ceny_grp s� poprawne. 
#'Je�li parametry nie s� poprawne, to zatrzymuje dzia�anie funkcji.
#'
#'@param marka Marka szukanych samochod�w.
#'@param model Model szukanych samochod�w.
#'@param rok Rok szukanych samochod�w.
#'@param dane Zbi�r danych, w kt�rym sprawdzane s� warunki.
sprawdz_parametry <- function (marka, modele, lata, dane = auta2012) {
  stopifnot(czy_marka_jest_poprawna(marka, dane))
  for (model in modele) {
    stopifnot(czy_model_jest_poprawny(marka, model, dane))
  }
  for (rok in lata) {
    stopifnot(czy_rok_jest_poprawny(marka, model, rok, dane))
  }
}

#'Wypisanie podsumowania
#'
#'Wypisuje podsumowanie dla danego zapytania funkcji statystyki_ceny_grp.
#'Zak�adamy, �e zapytanie jest poprawne.
#'
#'@param marka Marka szukanych samochod�w.
#'@param model Model szukanych samochod�w.
#'@param rok Rok szukanych samochod�w.
#'@param dane Zbi�r danych, w kt�rym sprawdzane s� warunki.
wypisz_podsumowanie_grp <- function (marka, modele, lata, dane = auta2012) {
  dane %>% 
    filter(Marka == marka, Model %in% modele, Rok.produkcji %in% lata) %>%
    group_by(Rok.produkcji) %>%
    summarise(mediana_ceny_w_PLN = median(Cena.w.PLN, na.rm = TRUE))
}

#'Statystyki modeli w latach
#'
#'Wypisuje �redni� cen� w PLN aut danej marki i modeli, grupuj�c po danych latach.
#'
#'@param marka Marka szukanych samochod�w.
#'@param modele Modele szukanych samochod�w.
#'@param lata Lata, po kt�rych grupujemy statystyk�.
#'@param dane Zbi�r danych, na kt�rym operujemy.
#'
#'@export
statystyki_ceny_grp <- function (marka, modele, lata, dane = auta2012) {
  sprawdz_parametry(marka, modele, lata, dane)
  wypisz_podsumowanie_grp(marka, modele, lata, dane)
}